package com.ust_global.user;

import java.util.List;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;



public class UserDetailsTestClient {

	public static void main(String[] args) throws NamingException {
		// This is a test client class for UserDetails EJB Module
		
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL,"localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES,"org.jboss.naming:org.jnp.interfaces");
	
		Context ctx=new InitialContext(p);
		
		UserDetailsBeanRemote userdr=(UserDetailsBeanRemote) ctx.lookup("UserDetailsBean/remote");
		
		//Read single user
//		UserDetails user=userdr.readUserDetails("AneenaMel");
//		if(user!=null)		{
//		System.out.println("Found");
//		System.out.println("Name: "+user.getName()+"\nUser Name: "+user.getUserName()+"\nEmail Id: "+user.getEmail()+"\nMobile Number: "+user.getMobileNumber());
//		}
//		else
//		{
//			System.out.println("no such user");
//		
//		
//		}
		
//		add user details
		
		UserDetails user=new UserDetails();
		user.setName("Vaisakh");
		user.setUserName("vaisakhv001");
		user.setEmail("vaisakh@gmail.com");
		user.setMobileNumber(992222111L);//please add L, because the data type is 'Long'
		userdr.addUser(user);
		LoginCredentialsBeanRemote usr=(LoginCredentialsBeanRemote) ctx.lookup("LoginCredentialsBean/remote");
		User userLogin=new User();
		userLogin.setUserName("vaisakhv001");
		userLogin.setPassWord("pass123");
		usr.addUser(userLogin);
	
		//update user details
		
//		UserDetails u=userdr.updateUserDetails("AneenaMetallo", "AneenaMel", "aneenametallo@yahoo.com", 9898444444L);
//		if(u!=null)
//			System.out.println("Successfully updated");
//		else
//			System.out.println("No such record found");
		
		//delete user details
//		userdr.removeUserDetails("AneenaMel");
		
		//To view all users details
			
		List<UserDetails>AllUserList=userdr.viewAllDetails();
		
		for (int i = 0; i < AllUserList.size(); i++) {
			
			System.out.println("Name: "+AllUserList.get(i).getName()+", Mobile Number:"+AllUserList.get(i).getMobileNumber());
			System.out.println("\n");
		}
		
				
	}

}
