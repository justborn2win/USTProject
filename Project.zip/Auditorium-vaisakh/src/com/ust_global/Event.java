/*
 * 
 * This is the POJO class for JSF 1.x
 * For the front end of Auditorium project
 * Group 3
 * ALPHA 1133
 * 
 * 
 * */
 package com.ust_global;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import com.ust_global.admin.EventsBeanRemote;
import com.ust_global.user.Ticket;
import com.ust_global.user.TicketBeanRemote;
import com.ust_global.user.User;

public class Event 
{
	private String eventId;
	private String eventName;
	private Date eventDate;
	private String eventCategory;
	private String seatsAvailable;
	private double ticketPrice;
	private int seatStatus;
	private String allSeats;
	private int selectedSeat;
	
	private List<String> allSeatsList=new ArrayList<String>();
	private List<String> allAvailableSeats=new ArrayList<String>();
	private List<Integer> allSeatStatus=new ArrayList<Integer>();
	
	String msg = " ";
	long lastTicketNumber;
	@SuppressWarnings("unused")
	public String createEvent() throws NamingException
	{
		
		Properties p = new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		Context ctx;
		ctx = new InitialContext(p);
		EventsBeanRemote remote = (EventsBeanRemote) ctx.lookup("EventsBean/remote");
		
		com.ust_global.admin.Event event=new com.ust_global.admin.Event();
		
		event.setEventId(getEventId());
		event.setEventName(getEventName());
		event.setEventCategory(getEventCategory());
		event.setEventDate(getEventDate());
		event.setSeatsAvailable(getSeatsAvailable());
		event.setTicketPrice(getTicketPrice());
		event.setSeatStatus(getSeatStatus());
		
		if(event!=null)
		{
			try
			{
				remote.createEvent(event);
				msg="";//success
			}
			catch (Exception e) 
			{
				//eventID already exists
				msg="";//fail
			}
		}
		else
			msg="";//fail
		return msg;
	}
	
	public String updateEvent() throws NamingException
	{
		Properties p = new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		Context ctx;
		ctx = new InitialContext(p);
		EventsBeanRemote remote = (EventsBeanRemote) ctx.lookup("EventsBean/remote");
		
		if(remote!=null)
		{
			try
			{
			remote.updateEvent(getEventId(), getEventName(), getEventDate(), getEventCategory(), getSeatsAvailable(),getSeatStatus(), getTicketPrice(),getAllSeats());
			}
			catch (Exception e) 
			{
				msg="";//fail
			}
		}
		else
			msg="";//fail
		return msg;
	}
	
	@SuppressWarnings("unused")
	public String viewAllEvents() throws NamingException
	{
		Properties p = new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		Context ctx;
		ctx = new InitialContext(p);
		EventsBeanRemote remote = (EventsBeanRemote) ctx.lookup("EventsBean/remote");
		
		if(remote!=null)
		{
			List<com.ust_global.admin.Event> allEvents=remote.allEvents();
			msg="";//success
		}
		else
			msg="";//fail
		return msg;
	}
	
	public String cancelEvent() throws NamingException
	{
		Properties p = new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		Context ctx;
		ctx = new InitialContext(p);
		EventsBeanRemote remote = (EventsBeanRemote) ctx.lookup("EventsBean/remote");
		
		if(remote!=null)
		{
			try
			{
				remote.cancelEvent(getEventId());
				msg="";//success
			}
			catch (Exception e)
			{
				msg="";//fail
			}
		}
		
		return msg;
	}
	
	public String searchEventById() throws NamingException
	{
		msg="";//fail
		Properties p = new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		Context ctx;
		ctx = new InitialContext(p);
		EventsBeanRemote remote = (EventsBeanRemote) ctx.lookup("EventsBean/remote");
		if(remote!=null)
		{
			com.ust_global.admin.Event event=remote.searchEvent(getEventId());
			if(event!=null)
			{
				msg="";//success
			}
		}
		return msg;	
	}
	
	public String bookATicket() throws NamingException
	{
		msg="";//fail
		
		Properties p = new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		Context ctx;
		ctx = new InitialContext(p);
		EventsBeanRemote remote = (EventsBeanRemote) ctx.lookup("EventsBean/remote");
		List<com.ust_global.admin.Event> all=remote.allEvents();
		
		List tcktNumber=new ArrayList();
		TicketBeanRemote ticketRemote=(TicketBeanRemote) ctx.lookup("TicketBean/remote");
		List<Ticket> allTicket=ticketRemote.viewAll();
		for(Ticket t:allTicket)
		{
			long tNumber=t.getTicketNumber();
			tcktNumber.add(tNumber);
			lastTicketNumber=tNumber+1;
		}
		
		for(com.ust_global.admin.Event event:all)
		{
			String seat=event.getSeatsAvailable();
			int status=event.getSeatStatus();
			allSeatsList.add(seat);
			allSeatStatus.add(status);
			
			
			for (int i = 0; i < allSeatStatus.size(); i++)
			{
				if(allSeatStatus.get(i).equals(0))
				{
					allAvailableSeats.add(allSeatsList.get(i));//now 'allAvailableSeats' have all the available seats name(A12)
				}
			}
		}
		/*
		 * if the user selects the 4th seat the element at 4th index in the allSeatStatus arraylist should be 1 instead of 0; 
		 * int selectedSeat is the index number of the seat in the arraylist of the availableSeats list
		 * 
		 * */
		if(allSeatStatus.get(selectedSeat).equals(0))//if the seat is available
		{
			allSeatStatus.add(selectedSeat, 1);//it will be booked
//String eventId, String eventName, Date eventDate,String eventCategory, String seatAvailble,int seatStatus ,double ticketPrice,String allSeats);
			remote.updateEvent(getEventId(), getEventName(), getEventDate(), getEventCategory(), getSeatsAvailable(), getSeatStatus(), getTicketPrice(),getAllSeats());
			TicketBeanRemote ticket=(TicketBeanRemote) ctx.lookup("TicketBean/remote");
			Ticket tckt=new Ticket();
			User user=new User();
			tckt.setEventId(getEventId());
			tckt.setEventName(getEventName());
			tckt.setSelectedDate(getEventDate());
			tckt.setUserName(user.getUserName());
			tckt.setTicketNumber(lastTicketNumber);
			Ticket newTicket=ticket.createTicket(tckt);
			if(newTicket!=null)
			{
				msg="";//success
			}
	}
		return msg;
	}
	
	
	
	public String getEventId() {
		return eventId;
	}
	public void setEventId(String eventId) {
		this.eventId = eventId;
	}
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	public Date getEventDate() {
		return eventDate;
	}
	public void setEventDate(Date eventDate) {
		this.eventDate = eventDate;
	}
	public String getEventCategory() {
		return eventCategory;
	}
	public void setEventCategory(String eventCategory) {
		this.eventCategory = eventCategory;
	}
	public String getSeatsAvailable() {
		return seatsAvailable;
	}
	public void setSeatsAvailable(String seatsAvailable) {
		this.seatsAvailable = seatsAvailable;
	}
	public double getTicketPrice() {
		return ticketPrice;
	}
	public void setTicketPrice(double ticketPrice) {
		this.ticketPrice = ticketPrice;
	}

	public int getSeatStatus() {
		return seatStatus;
	}

	public void setSeatStatus(int seatStatus) {
		this.seatStatus = seatStatus;
	}

	public String getAllSeats() {
		return allSeats;
	}

	public void setAllSeats(String allSeats) {
		this.allSeats = allSeats;
	}

	public List<String> getAllSeatsList() {
		return allSeatsList;
	}

	public void setAllSeatsList(List<String> allSeatsList) {
		this.allSeatsList = allSeatsList;
	}

	public List<Integer> getAllSeatStatus() {
		return allSeatStatus;
	}

	public void setAllSeatStatus(List<Integer> allSeatStatus) {
		this.allSeatStatus = allSeatStatus;
	}

	public List<String> getAllAvailableSeats() {
		return allAvailableSeats;
	}

	public void setAllAvailableSeats(List<String> allAvailableSeats) {
		this.allAvailableSeats = allAvailableSeats;
	}
	
	
	
}
