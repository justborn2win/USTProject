package com.ust_global.user;
import java.sql.Date;
import java.util.List;

import javax.ejb.Remote;
@Remote
public interface TicketBeanRemote 
{
	/*
SQL> desc selectedEvents;
 Name                                      Null?    Type
 ----------------------------------------- -------- ----------------------------
 TICKETNUMBER                              NOT NULL NUMBER(20)
 USERNAME                                           VARCHAR2(30)
 EVENTID                                            VARCHAR2(20)
 EVENTNAME                                          VARCHAR2(30)
 SELECTEDDATE                                       DATE
 SEATNUMBER                                         VARCHAR2(30)
 TICKETPRICE                                        NUMBER
 NOOFSEATS                                          NUMBER
	*/
	public Ticket createTicket(Ticket ticket);
	public void cancelTicket(long ticketId);
	public Ticket searchTicket(long ticketId);
	public List<Ticket> viewAll();
	public Ticket updateTicket(long ticketId, String userName, String eventId, String eventName, Date selectedData, int noOfSeats,String seatNumber, double ticketPrice);
}
