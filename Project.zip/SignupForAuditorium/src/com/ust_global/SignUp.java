package com.ust_global;

import java.util.Properties;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.http.HttpSession;

import com.ust_global.user.UserDetails;
import com.ust_global.user.UserDetailsBeanRemote;

public class SignUp {


	String name;
	String userName;
	String email;
	long mobile;
	
	
	public SignUp()
	{
		
	}
	
	
	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public long getMobile() {
		return mobile;
	}


	public void setMobile(long mobile) {
		this.mobile = mobile;
	}
	
	
	public String signUp() throws NamingException
	{
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL,"localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES,"org.jboss.naming:org.jnp.interfaces");
		Context ctx=new InitialContext(p);
		UserDetailsBeanRemote users=(UserDetailsBeanRemote) ctx.lookup("UserDetailsBean/remote");
		UserDetails user = new UserDetails();
		user.setName(name);
		user.setUserName(userName);
		user.setEmail(email);
		user.setMobileNumber(mobile);
		if(users!=null)
		{
			FacesContext fc = FacesContext.getCurrentInstance();
			ExternalContext ec = fc.getExternalContext();
			HttpSession session = (HttpSession) ec.getSession(false);
			session.setAttribute("userName", this.userName);
			users.addUser(user);
			return "successAdd";
		}
		else
		{
			return "failureAdd";
		}	
		
	}



}
